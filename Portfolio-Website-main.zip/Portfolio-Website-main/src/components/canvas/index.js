export { default as EarthCanvas } from "./Earth";
export { default as BallCanvas } from "./Ball";
export { default as ComputersCanvas } from "./Computers";
export { default as StarsCanvas } from "./Stars";
